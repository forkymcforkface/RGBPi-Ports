#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x67cfad3, "__platform_driver_register" },
	{ 0x83ee3166, "drm_bridge_remove" },
	{ 0x122c3a7e, "_printk" },
	{ 0x1eb7444, "drm_connector_init" },
	{ 0x7c0d9cad, "drm_display_info_set_bus_formats" },
	{ 0x772063c5, "drm_connector_attach_encoder" },
	{ 0xb11ac7a7, "__drm_err" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xfed57d22, "drm_mode_create" },
	{ 0x66cf2f64, "drm_display_mode_from_videomode" },
	{ 0x4a35d30d, "drm_mode_set_name" },
	{ 0xf1b5340a, "drm_mode_vrefresh" },
	{ 0xf59db68a, "drm_mode_probed_add" },
	{ 0x427a1427, "devm_kmalloc" },
	{ 0x794b7bab, "drm_bridge_add" },
	{ 0x738c265, "platform_driver_unregister" },
	{ 0xdcb764ad, "memset" },
	{ 0xa0e3b97c, "filp_open" },
	{ 0x750e35b0, "kernel_read" },
	{ 0xa756faf2, "filp_close" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0x6ebfdf3b, "drm_atomic_helper_connector_reset" },
	{ 0xceb7f35d, "drm_helper_probe_single_connector_modes" },
	{ 0x7ea1d299, "drm_connector_cleanup" },
	{ 0x98b826f5, "drm_atomic_helper_connector_duplicate_state" },
	{ 0xc687f3e3, "drm_atomic_helper_connector_destroy_state" },
	{ 0x3a3b9f5d, "module_layout" },
};

MODULE_INFO(depends, "drm,drm_kms_helper");

MODULE_ALIAS("of:N*T*Craspberrypi,dpidac");
MODULE_ALIAS("of:N*T*Craspberrypi,dpidacC*");

MODULE_INFO(srcversion, "BE79A55022A378658833D37");
