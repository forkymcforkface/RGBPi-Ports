#!/bin/bash

SCRIPT_DIR="$(dirname "$0")"

make -C "$SCRIPT_DIR/vga666" clean
make -C "$SCRIPT_DIR/vga666" uninstall
make -C "$SCRIPT_DIR/vga666"
make -C "$SCRIPT_DIR/vga666" install
sync
sync
reboot
