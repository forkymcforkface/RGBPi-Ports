#!/bin/bash

CORES_CFG="/opt/rgbpi/ui/data/cores.cfg"

[ ! -f /opt/retroarch/retroarch.bak ] && sudo cp /opt/retroarch/retroarch /opt/retroarch/retroarch.bak
sudo cp "$(dirname "$0")/retroarch" /opt/retroarch/retroarch
sudo chmod 777 /opt/retroarch/retroarch
sudo cp -r "$(dirname "$0")/shaders" /root/.config/retroarch/
sed -i 's/^crt_type = .*/crt_type = arcade_31/' /opt/rgbpi/ui/config.ini
sed -i 's/reicast_threaded_rendering = "enabled"/reicast_threaded_rendering = "disabled"/' $CORES_CFG
sed -i 's/reicast_internal_resolution = "320x240"/reicast_internal_resolution = "640x480"/' $CORES_CFG
sed -i 's/mupen64plus-next-ThreadedRenderer = "True"/mupen64plus-next-ThreadedRenderer = "False"/' $CORES_CFG
sed -i 's/mupen64plus-ThreadedRenderer = "True"/mupen64plus-ThreadedRenderer = "False"/' $CORES_CFG

sync

sudo bash -c 'cat <<EOF >> /media/sd/gameconfig/sys_override/global.cfg
video_shader_enable = "true"
quick_menu_show_shaders = "true"
EOF'

sudo bash -c 'cat <<EOF > /opt/rgbpi/ui/data/update_timings.sh
#!/bin/bash
TIMINGS="320 1 20 48 17 240 1 5 1 16 0 0 0 120.229008 0 12726000 1
512 1 32 50 72 224 1 9 3 24 0 0 0 60.098809 0 10391084 1"
echo "\$TIMINGS" > /opt/rgbpi/ui/data/timings.dat
echo "\$TIMINGS" > /opt/rgbpi/ui/data/backup/timings.15
sync
EOF'

sudo chmod +x /opt/rgbpi/ui/data/update_timings.sh

sudo bash -c 'cat <<EOF > /etc/systemd/system/update_timings.service
[Unit]
Description=Update Timings on Shutdown
DefaultDependencies=no
Before=shutdown.target
[Service]
Type=oneshot
ExecStart=/opt/rgbpi/ui/data/update_timings.sh
RemainAfterExit=true
[Install]
WantedBy=halt.target reboot.target shutdown.target
EOF'

sudo bash -c 'cat <<EOF > /opt/rgbpi/autostart.sh
#!/bin/bash
cd /opt/rgbpi/ui 2> /dev/null
rm -rf /opt/rgbpi/ui/temp/* 2> /dev/null
/usr/bin/python3 /opt/rgbpi/ui/rgbpiui.pyc 2> /opt/rgbpi/ui/logs/error.log
EOF'

sudo systemctl enable update_timings.service
sudo systemctl start update_timings.service
sudo reboot
