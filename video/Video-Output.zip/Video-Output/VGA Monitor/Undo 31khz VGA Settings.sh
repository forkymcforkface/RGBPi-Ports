#!/bin/bash

CORES_CFG="/opt/rgbpi/ui/data/cores.cfg"

# Restore retroarch from backup if available
[ -f /opt/retroarch/retroarch.bak ] && sudo mv /opt/retroarch/retroarch.bak /opt/retroarch/retroarch

# Revert the crt_type change in config.ini
sed -i 's/^crt_type = arcade_31/crt_type = arcade_15/' /opt/rgbpi/ui/config.ini

# Remove update_timings.sh and its service
sudo rm -f /opt/rgbpi/ui/data/update_timings.sh
sudo systemctl disable update_timings.service
sudo rm -f /etc/systemd/system/update_timings.service

# Define AUTOSTART_FILE directly since DEST_DIR is not defined
AUTOSTART_FILE="/opt/rgbpi/autostart.sh"
cat <<EOL > $AUTOSTART_FILE
#!/bin/bash
cd /opt/rgbpi/ui 2> /dev/null
rm -rf /opt/rgbpi/ui/temp/* 2> /dev/null
CRT_TYPE=\$(grep '^crt_type' /opt/rgbpi/ui/config.ini 2> /dev/null | cut -d'=' -f2 | tr -d ' ')
if [[ "\$CRT_TYPE" == "arcade_15_25_31" || "\$CRT_TYPE" == "ms2930" || "\$CRT_TYPE" == "arcade_31" ]]; then
  if [ -f /opt/retroarch/retroarch ] && [ -f /opt/retroarch/retroarch_31khz ]; then
    mv /opt/retroarch/retroarch /opt/retroarch/retroarch_15khz
    mv /opt/retroarch/retroarch_31khz /opt/retroarch/retroarch
  fi
elif [[ "\$CRT_TYPE" == "generic_15" || "\$CRT_TYPE" == "arcade_15" || "\$CRT_TYPE" == "arcade_15_25" ]]; then
  if [ -f /opt/retroarch/retroarch ] && [ -f /opt/retroarch/retroarch_15khz ]; then
    mv /opt/retroarch/retroarch /opt/retroarch/retroarch_31khz
    mv /opt/retroarch/retroarch_15khz /opt/retroarch/retroarch
  fi
fi
/usr/bin/python3 /opt/rgbpi/ui/rgbpiui.pyc 2> /opt/rgbpi/ui/logs/error.log
EOL

# Make the autostart file executable
chmod +x $AUTOSTART_FILE

sync

reboot