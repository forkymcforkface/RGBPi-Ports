#!/bin/bash

SCRIPT_DIR="$(dirname "$0")"

make -C "$SCRIPT_DIR/vga888" clean
make -C "$SCRIPT_DIR/vga888" uninstall
make -C "$SCRIPT_DIR/vga888"
make -C "$SCRIPT_DIR/vga888" install
sync
sync
reboot
