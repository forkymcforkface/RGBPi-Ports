#!/bin/bash

SCRIPT_DIR="$(dirname "$0")"

make -C "$SCRIPT_DIR/rgbpi" clean
make -C "$SCRIPT_DIR/rgbpi" uninstall
make -C "$SCRIPT_DIR/rgbpi"
make -C "$SCRIPT_DIR/rgbpi" install
sync
sync
reboot
